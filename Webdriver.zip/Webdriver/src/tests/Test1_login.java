package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Test1_login {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= new FirefoxDriver();
		driver.get("http://d3a.io/projects");
		Thread.sleep(100);
		WebElement username = driver.findElement(By.id("email"));
		username.sendKeys("akanaswamy20@gmail.com");
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("@ab123456");
		WebElement button = driver.findElement(By.className("button__label"));
		button.click();
	    System.out.println("Login successful");
		driver.close();

		


		
	

	}

	private static void assertTrue(boolean endsWith) {
		// TODO Auto-generated method stub
		
	}

}
