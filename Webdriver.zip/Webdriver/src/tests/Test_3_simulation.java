package tests;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Test_3_simulation {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= new FirefoxDriver();
		driver.get("http://d3a.io/projects");
		Thread.sleep(100);
		WebElement username = driver.findElement(By.id("email"));
		username.sendKeys("akanaswamy20@gmail.com");
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("@ab123456");
		driver.findElement(By.className("button__label")).click();
		Thread.sleep(400);
		/*creation of project*/
       driver.findElement(By.className("icon-projects")).click();
        Thread.sleep(1000);
        driver.findElement(By.className("saved-project__headline__name__text")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/section[1]/div[1]/div[2]/button[1]/span[1]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/button[1]")).click();
        driver.close();

	}

}
